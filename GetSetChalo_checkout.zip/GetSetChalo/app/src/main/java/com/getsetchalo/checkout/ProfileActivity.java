package com.getsetchalo.checkout;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        findViewById(R.id.btnProfileBack).setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.slide_out_right);
        });

        findViewById(R.id.btnLogout).setOnClickListener(v ->
            Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
        );
    }
}
