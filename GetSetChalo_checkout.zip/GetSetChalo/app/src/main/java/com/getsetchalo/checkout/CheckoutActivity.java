package com.getsetchalo.checkout;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;

public class CheckoutActivity extends AppCompatActivity {

    // --- Price state ---
    private static final int BASE_ROOM = 7990;
    private static final double TAX_RATE = 0.18;
    private int addonTotal = 1199; // spa(899) + breakfast(300) pre-selected
    private int promoDiscount = 0;
    private Button activePromoChip = null;

    // --- Addon prices ---
    private static final int PRICE_SPA = 899;
    private static final int PRICE_BREAKFAST = 300;
    private static final int PRICE_TRANSFER = 650;
    private static final int PRICE_TOUR = 500;
    private static final int PRICE_ADVENTURE = 420;
    private static final int PRICE_PHOTO = 199;

    // --- Views ---
    private TextView tvAddonTotal, tvSubtotal, tvTax, tvTotal, tvDiscountAmt;
    private LinearLayout discountRow;
    private TextView tvPromoHeaderSub, tvAddonHeaderSub, tvPromoBadge;

    // Guest section
    private LinearLayout guestBody, formMainGuest, formGuest2;
    private TextView guestChevron;
    private Button tabMainGuest, tabGuest2;
    private TextView tvMainAadharAttached, tvG2AadharAttached;

    // Promo section
    private LinearLayout promoBody;
    private TextView promoChevron;

    // Addon section
    private LinearLayout addonBody;
    private TextView addonChevron;

    // Addon item views
    private LinearLayout addonSpa, addonBreakfast, addonTransfer, addonTour, addonAdventure, addonPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        bindViews();
        setupListeners();
        updatePriceSummary();
    }

    private void bindViews() {
        tvAddonTotal = findViewById(R.id.tvAddonTotal);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvTax = findViewById(R.id.tvTax);
        tvTotal = findViewById(R.id.tvTotal);
        tvDiscountAmt = findViewById(R.id.tvDiscountAmt);
        discountRow = findViewById(R.id.discountRow);
        tvPromoHeaderSub = findViewById(R.id.tvPromoHeaderSub);
        tvAddonHeaderSub = findViewById(R.id.tvAddonHeaderSub);
        tvPromoBadge = findViewById(R.id.tvPromoBadge);

        guestBody = findViewById(R.id.guestBody);
        guestChevron = findViewById(R.id.guestChevron);
        formMainGuest = findViewById(R.id.formMainGuest);
        formGuest2 = findViewById(R.id.formGuest2);
        tabMainGuest = findViewById(R.id.tabMainGuest);
        tabGuest2 = findViewById(R.id.tabGuest2);
        tvMainAadharAttached = findViewById(R.id.tvMainAadharAttached);
        tvG2AadharAttached = findViewById(R.id.tvG2AadharAttached);

        promoBody = findViewById(R.id.promoBody);
        promoChevron = findViewById(R.id.promoChevron);
        addonBody = findViewById(R.id.addonBody);
        addonChevron = findViewById(R.id.addonChevron);

        addonSpa = findViewById(R.id.addonSpa);
        addonBreakfast = findViewById(R.id.addonBreakfast);
        addonTransfer = findViewById(R.id.addonTransfer);
        addonTour = findViewById(R.id.addonTour);
        addonAdventure = findViewById(R.id.addonAdventure);
        addonPhoto = findViewById(R.id.addonPhoto);
    }

    private void setupListeners() {
        // Back button
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Profile button
        findViewById(R.id.btnProfile).setOnClickListener(v -> {
            startActivity(new Intent(this, ProfileActivity.class));
            overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.fade_out);
        });

        // Guest section toggle
        findViewById(R.id.guestHeader).setOnClickListener(v -> toggleSection(guestBody, guestChevron));

        // Guest tabs
        tabMainGuest.setOnClickListener(v -> switchGuestTab(0));
        tabGuest2.setOnClickListener(v -> switchGuestTab(1));

        // Attach buttons (simulate file pick)
        findViewById(R.id.btnAttachMainAadhar).setOnClickListener(v -> {
            tvMainAadharAttached.setVisibility(View.VISIBLE);
            Toast.makeText(this, "aadhar_main.pdf attached", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnAttachG2Aadhar).setOnClickListener(v -> {
            tvG2AadharAttached.setVisibility(View.VISIBLE);
            Toast.makeText(this, "aadhar_guest2.pdf attached", Toast.LENGTH_SHORT).show();
        });

        // Promo section toggle
        findViewById(R.id.promoHeader).setOnClickListener(v -> toggleSection(promoBody, promoChevron));

        // Promo chips
        Button chipEarlyBird = findViewById(R.id.chipEarlyBird);
        Button chipFirst50 = findViewById(R.id.chipFirst50);
        Button chipMonsoon = findViewById(R.id.chipMonsoon);
        Button chipGSC200 = findViewById(R.id.chipGSC200);

        chipEarlyBird.setOnClickListener(v -> togglePromo(chipEarlyBird, "15pct", "EARLYBIRD 15% applied"));
        chipFirst50.setOnClickListener(v -> togglePromo(chipFirst50, "50flat", "FIRST50 applied"));
        chipMonsoon.setOnClickListener(v -> togglePromo(chipMonsoon, "10pct", "MONSOON10 applied"));
        chipGSC200.setOnClickListener(v -> togglePromo(chipGSC200, "200flat", "GSC200 applied"));

        // Addon section toggle
        findViewById(R.id.addonHeader).setOnClickListener(v -> toggleSection(addonBody, addonChevron));

        // Addon tiles
        addonSpa.setOnClickListener(v -> toggleAddon(addonSpa, PRICE_SPA));
        addonBreakfast.setOnClickListener(v -> toggleAddon(addonBreakfast, PRICE_BREAKFAST));
        addonTransfer.setOnClickListener(v -> toggleAddon(addonTransfer, PRICE_TRANSFER));
        addonTour.setOnClickListener(v -> toggleAddon(addonTour, PRICE_TOUR));
        addonAdventure.setOnClickListener(v -> toggleAddon(addonAdventure, PRICE_ADVENTURE));
        addonPhoto.setOnClickListener(v -> toggleAddon(addonPhoto, PRICE_PHOTO));

        // Main CTA
        findViewById(R.id.btnProceedConfirm).setOnClickListener(v -> showReservationDialog());
    }

    // ---- Section collapse/expand ----
    private void toggleSection(LinearLayout body, TextView chevron) {
        if (body.getVisibility() == View.GONE) {
            body.setVisibility(View.VISIBLE);
            chevron.setText("⌄");
        } else {
            body.setVisibility(View.GONE);
            chevron.setText("›");
        }
    }

    // ---- Guest tab switch ----
    private void switchGuestTab(int index) {
        if (index == 0) {
            tabMainGuest.setBackgroundResource(R.drawable.bg_tab_active);
            tabMainGuest.setTextColor(getResources().getColor(R.color.gold));
            tabGuest2.setBackgroundResource(R.drawable.bg_tab_inactive);
            tabGuest2.setTextColor(getResources().getColor(R.color.text_secondary));
            formMainGuest.setVisibility(View.VISIBLE);
            formGuest2.setVisibility(View.GONE);
        } else {
            tabGuest2.setBackgroundResource(R.drawable.bg_tab_active);
            tabGuest2.setTextColor(getResources().getColor(R.color.gold));
            tabMainGuest.setBackgroundResource(R.drawable.bg_tab_inactive);
            tabMainGuest.setTextColor(getResources().getColor(R.color.text_secondary));
            formMainGuest.setVisibility(View.GONE);
            formGuest2.setVisibility(View.VISIBLE);
        }
    }

    // ---- Promo toggle ----
    private void togglePromo(Button chip, String tag, String label) {
        if (activePromoChip == chip) {
            // Deselect
            chip.setBackgroundResource(R.drawable.bg_promo_chip);
            chip.setTextColor(getResources().getColor(R.color.gold));
            activePromoChip = null;
            promoDiscount = 0;
            tvPromoBadge.setVisibility(View.GONE);
            tvPromoHeaderSub.setText("No promo applied");
        } else {
            // Deselect previous
            if (activePromoChip != null) {
                activePromoChip.setBackgroundResource(R.drawable.bg_promo_chip);
                activePromoChip.setTextColor(getResources().getColor(R.color.gold));
            }
            chip.setBackgroundResource(R.drawable.bg_promo_chip_active);
            chip.setTextColor(getResources().getColor(R.color.white));
            activePromoChip = chip;

            int base = BASE_ROOM + addonTotal;
            if (tag.endsWith("pct")) {
                int pct = Integer.parseInt(tag.replace("pct", ""));
                promoDiscount = (int) Math.round(base * pct / 100.0);
            } else {
                promoDiscount = Integer.parseInt(tag.replace("flat", ""));
            }
            tvPromoBadge.setText("✓ You save ₹" + formatINR(promoDiscount) + "!");
            tvPromoBadge.setVisibility(View.VISIBLE);
            tvPromoHeaderSub.setText(label);
        }
        updatePriceSummary();
    }

    // ---- Addon toggle ----
    private void toggleAddon(LinearLayout tile, int price) {
        String tag = (String) tile.getTag();
        if ("selected".equals(tag)) {
            tile.setTag("unselected");
            tile.setBackgroundResource(R.drawable.bg_addon);
            addonTotal -= price;
        } else {
            tile.setTag("selected");
            tile.setBackgroundResource(R.drawable.bg_addon_selected);
            addonTotal += price;
        }
        updateAddonHeader();
        updatePriceSummary();
    }

    private void updateAddonHeader() {
        StringBuilder sb = new StringBuilder();
        if ("selected".equals(addonSpa.getTag())) appendComma(sb, "Spa");
        if ("selected".equals(addonBreakfast.getTag())) appendComma(sb, "Breakfast");
        if ("selected".equals(addonTransfer.getTag())) appendComma(sb, "Transfer");
        if ("selected".equals(addonTour.getTag())) appendComma(sb, "Tour");
        if ("selected".equals(addonAdventure.getTag())) appendComma(sb, "Adventure");
        if ("selected".equals(addonPhoto.getTag())) appendComma(sb, "Photo");
        tvAddonHeaderSub.setText(sb.length() > 0 ? sb.toString() : "None selected");
    }

    private void appendComma(StringBuilder sb, String s) {
        if (sb.length() > 0) sb.append(" + ");
        sb.append(s);
    }

    // ---- Price calculation ----
    private void updatePriceSummary() {
        int subtotal = BASE_ROOM + addonTotal - promoDiscount;
        int tax = (int) Math.round(subtotal * TAX_RATE);
        int total = subtotal + tax;

        tvAddonTotal.setText("₹" + formatINR(addonTotal));
        tvSubtotal.setText("₹" + formatINR(subtotal));
        tvTax.setText("₹" + formatINR(tax));
        tvTotal.setText("₹" + formatINR(total));

        if (promoDiscount > 0) {
            discountRow.setVisibility(View.VISIBLE);
            tvDiscountAmt.setText("-₹" + formatINR(promoDiscount));
        } else {
            discountRow.setVisibility(View.GONE);
        }
    }

    private String formatINR(int amount) {
        return NumberFormat.getNumberInstance(new Locale("en", "IN")).format(amount);
    }

    // ---- Reservation Dialog ----
    private void showReservationDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_reservation);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.88),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);

        // Compute deadline = check-in (Apr 12 2026) minus 7 days = Apr 5 2026
        Calendar checkIn = Calendar.getInstance();
        checkIn.set(2026, Calendar.APRIL, 12);
        Calendar deadline = (Calendar) checkIn.clone();
        deadline.add(Calendar.DAY_OF_MONTH, -7);
        String deadlineStr = String.format(Locale.getDefault(), "%02d/%02d/%04d",
                deadline.get(Calendar.DAY_OF_MONTH),
                deadline.get(Calendar.MONTH) + 1,
                deadline.get(Calendar.YEAR));

        TextView tvDeadline = dialog.findViewById(R.id.tvDeadline);
        tvDeadline.setText(deadlineStr);

        dialog.findViewById(R.id.btnPayNow).setOnClickListener(v -> {
            dialog.dismiss();
            showPaymentDialog();
        });

        dialog.findViewById(R.id.btnPayLater).setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(this, "Booking reserved! Pay before " + deadlineStr, Toast.LENGTH_LONG).show();
        });

        dialog.show();
    }

    // ---- Payment Dialog ----
    private void showPaymentDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_payment);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.88),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(true);

        // Show total
        int subtotal = BASE_ROOM + addonTotal - promoDiscount;
        int tax = (int) Math.round(subtotal * TAX_RATE);
        int total = subtotal + tax;
        TextView tvPayTotal = dialog.findViewById(R.id.tvPayTotal);
        tvPayTotal.setText("₹" + formatINR(total));

        // Payment spinner
        Spinner spinner = dialog.findViewById(R.id.spinnerPayment);
        String[] methods = {
            "Select payment method",
            "── Credit Card ──",
            "  Visa Credit · ending 1234",
            "  Mastercard Credit · ending 5678",
            "── Debit Card ──",
            "  Visa Debit · ending 9012",
            "  RuPay Debit · ending 3456",
            "── UPI ──",
            "  Google Pay (UPI)",
            "  PhonePe (UPI)",
            "  Paytm (UPI)",
            "  Enter UPI ID"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, methods) {
            @Override
            public boolean isEnabled(int position) {
                // Disable section headers
                return position != 1 && position != 4 && position != 7;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        EditText etUpiId = dialog.findViewById(R.id.etUpiId);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int pos, long id) {
                etUpiId.setVisibility(pos == 11 ? View.VISIBLE : View.GONE);
            }
            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        dialog.findViewById(R.id.btnConfirmPay).setOnClickListener(v -> {
            if (spinner.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Please select a payment method", Toast.LENGTH_SHORT).show();
                return;
            }
            dialog.dismiss();
            showSuccessDialog();
        });

        dialog.findViewById(R.id.btnCancelPay).setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    // ---- Success Dialog ----
    private void showSuccessDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_success);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.82),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);

        dialog.findViewById(R.id.btnDone).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }
}
